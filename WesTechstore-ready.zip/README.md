# WesTechstore

Practical AI for real life. Responsive bilingual storefront for a £19 one-to-one AI setup service and Wesland Institute learning previews.

## Publish with GitHub Pages

Open **Settings → Pages**, choose **Deploy from a branch**, select **main** and **/(root)**, then save.
